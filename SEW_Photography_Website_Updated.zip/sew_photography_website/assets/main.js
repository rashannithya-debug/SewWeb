// SEW Photography — navigation, portfolio filters and enquiry forms
const menuButton = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');
if (menuButton && nav) {
  menuButton.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    menuButton.setAttribute('aria-expanded', String(open));
    menuButton.textContent = open ? '✕' : '☰';
  });
  nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
    nav.classList.remove('open');
    menuButton.setAttribute('aria-expanded', 'false');
    menuButton.textContent = '☰';
  }));
}
document.querySelectorAll('#year').forEach(el => el.textContent = new Date().getFullYear());

const filterButtons = document.querySelectorAll('.filter');
const galleryItems = document.querySelectorAll('.gallery-item');
filterButtons.forEach(button => button.addEventListener('click', () => {
  filterButtons.forEach(b => b.classList.remove('active'));
  button.classList.add('active');
  const category = button.dataset.filter;
  galleryItems.forEach(item => {
    item.hidden = category !== 'all' && item.dataset.category !== category;
  });
}));

function openWhatsApp(lines) {
  const number = '94758754838';
  const url = `https://wa.me/${number}?text=${encodeURIComponent(lines.join('\n'))}`;
  window.open(url, '_blank', 'noopener');
}
const contactForm = document.querySelector('#contactForm');
if (contactForm) contactForm.addEventListener('submit', event => {
  event.preventDefault();
  const data = new FormData(contactForm);
  openWhatsApp([
    'Hello SEW Photography! I have an enquiry.',
    `Name: ${data.get('name')}`,
    `Email: ${data.get('email')}`,
    `Enquiry: ${data.get('type')}`,
    `Message: ${data.get('message')}`
  ]);
});
const bookingForm = document.querySelector('#bookingForm');
if (bookingForm) bookingForm.addEventListener('submit', event => {
  event.preventDefault();
  const data = new FormData(bookingForm);
  openWhatsApp([
    'Hello SEW Photography! I would like to enquire about a booking.',
    `Name: ${data.get('name')}`,
    `Phone: ${data.get('phone')}`,
    `Email: ${data.get('email') || 'Not provided'}`,
    `Session: ${data.get('type')}`,
    `Preferred date: ${data.get('date') || 'Flexible'}`,
    `Location: ${data.get('location') || 'To be discussed'}`,
    `More details: ${data.get('message') || 'Not provided'}`
  ]);
});
